
# Web Games Dataset

## Overview
- **Collection time**: 2026-06-20T07:19:30.666541
- **Sources**: Poki.com, Deadshot.io, Krunker.io, Fandom.com
- **Total records**: 52

## Files
| File | Description | Records |
|------|-------------|---------|
| poki_games.csv | poki_games data | 30 |
| deadshot_info.csv | deadshot_info data | 1 |
| krunker_stats.csv | krunker_stats data | 10 |
| game_categories.csv | game_categories data | 10 |
| summary.csv | summary data | 1 |

## Field Descriptions
### poki_games.csv
- title: game name
- url: game URL
- description: short description
- categories: comma-separated categories
- rating: user rating
- primary_category: main category

### krunker_stats.csv
- username: player name
- level: player level
- score: total score
- kills: kill count
- deaths: death count
- wins: wins
- games_played: number of games

### deadshot_info.csv
- name: game name
- type: genre
- maps: list of maps
- game_modes: available modes
- weapon_classes: weapon types

### game_categories.csv
- game: game name
- categories: list of categories
- category_count: number of categories

## Usage Example
```python
import pandas as pd
poki = pd.read_csv('web_games_dataset/poki_games.csv')
krunker = pd.read_csv('web_games_dataset/krunker_stats.csv')
```
