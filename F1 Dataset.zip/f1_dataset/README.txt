# Formula 1 Dataset – 50 Seasons (1974–2024)

Generated with FastF1. Contains:
- Race results, qualifying, sprint results
- Lap times (where available, from 1996+)
- Pit stops (where available, from 2011+)
- Driver, constructor, circuit, event metadata

All files are CSV. Columns follow FastF1 naming.
RaceId = "{year}_{round}"

**Note**: Data availability increases significantly from ~1983 onwards.
Lap times and pit stops are sparse before 1996/2011.
